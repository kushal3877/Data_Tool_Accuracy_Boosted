
import streamlit as st
import pandas as pd
import os
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix, ConfusionMatrixDisplay, roc_curve, auc
from sklearn.model_selection import train_test_split
import numpy as np

try:
    from xgboost import XGBClassifier
    xgb_available = True
except ImportError:
    xgb_available = False

st.set_page_config(layout="wide")
st.title("📊 Excel/CSV Multi-File Data Classifier Tool")

# Reset session button
if st.sidebar.button("🔁 Reset App"):
    st.session_state.clear()
    st.stop()  # Used as fallback instead of experimental_rerun

uploaded_files = st.file_uploader("Upload one or more Excel/CSV files", type=['csv', 'xlsx'], accept_multiple_files=True)

if uploaded_files:
    df_list = []
    for file in uploaded_files:
        ext = file.name.split('.')[-1]
        if ext == 'csv':
            df = pd.read_csv(file)
        else:
            df = pd.read_excel(file)
        df_list.append(df)

    df = pd.concat(df_list, ignore_index=True)

    st.subheader("📐 Dataset Overview")
    st.markdown(f"**Shape:** {df.shape}")
    st.markdown(f"**Size (rows x columns):** {df.shape[0]} rows × {df.shape[1]} columns")

    st.subheader("📋 Columns Info")
    col_info = pd.DataFrame({
        "Column": df.columns,
        "Data Type": df.dtypes.astype(str),
        "Missing Values": df.isnull().sum(),
        "Unique Values": df.nunique()
    })
    st.dataframe(col_info)

    st.subheader("✂️ Drop Unwanted Columns")
    columns_to_drop = st.multiselect("Select columns to drop from the dataset", df.columns)
    if st.button("Drop Selected Columns"):
        df.drop(columns=columns_to_drop, inplace=True)
        st.success(f"Dropped columns: {columns_to_drop}")

    st.subheader("🔍 Preview of the dataset")
    st.dataframe(df.head())

    st.subheader("🧹 Data Cleaning Options")
    if st.checkbox("Drop rows with missing values"):
        df.dropna(inplace=True)
    if st.checkbox("Drop duplicate rows"):
        df.drop_duplicates(inplace=True)
    if st.checkbox("Fill missing values with column mean"):
        df.fillna(df.mean(numeric_only=True), inplace=True)

    st.subheader("📊 Data Visualization")
    numeric_cols = df.select_dtypes(include=['float64', 'int64'])
    with st.expander("📌 Correlation Heatmap"):
        if not numeric_cols.empty:
            fig, ax = plt.subplots()
            sns.heatmap(numeric_cols.corr(), annot=True, cmap='coolwarm', ax=ax)
            st.pyplot(fig)

    with st.expander("📌 Histogram of Numeric Columns"):
        if not numeric_cols.empty:
            col = st.selectbox("Select column to plot histogram", numeric_cols.columns)
            fig, ax = plt.subplots()
            sns.histplot(df[col], kde=True, ax=ax)
            st.pyplot(fig)

    st.subheader("🎯 Model Training")
    target_column = st.selectbox("Select the target column (label)", df.columns)
    model_choice = st.selectbox("Choose model", [
        'Random Forest', 'Logistic Regression', 'Decision Tree', 
        'SVM', 'Naive Bayes'
    ] + (['XGBoost'] if xgb_available else []))

    st.subheader("🔄 Data Type Detection and Override")
    for col in df.columns:
        inferred_type = df[col].dtype
        selected_type = st.selectbox(f"Column '{col}' detected as {inferred_type}. Override?", 
                                     ['auto', 'int64', 'float64', 'object', 'bool'], key=col)
        if selected_type != 'auto':
            try:
                df[col] = df[col].astype(selected_type)
            except Exception as e:
                st.warning(f"❌ Could not convert {col} to {selected_type}: {e}")

    if st.button("Train Model"):
        X = df.drop(columns=[target_column])
        y = df[target_column]
        X = X.select_dtypes(include=['float64', 'int64'])

        if X.empty:
            st.warning("No numeric columns to train on.")
        else:
            
        # Separate numeric and categorical columns
        numeric_features = X.select_dtypes(include=['int64', 'float64']).columns.tolist()
        categorical_features = X.select_dtypes(include=['object', 'bool', 'category']).columns.tolist()

        # Column Transformer for preprocessing
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', StandardScaler(), numeric_features),
                ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
            ]
        )

        # Apply preprocessing
        X = preprocessor.fit_transform(X)

        # Feature selection: keep top 20 features
        selector = SelectKBest(score_func=f_classif, k=min(20, X.shape[1]))
        X = selector.fit_transform(X, y)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

            if model_choice == 'Random Forest':
                model = RandomForestClassifier(n_estimators=100, random_state=42)
            elif model_choice == 'Logistic Regression':
                model = LogisticRegression(max_iter=1000)
            elif model_choice == 'Decision Tree':
                model = DecisionTreeClassifier()
            elif model_choice == 'SVM':
                model = SVC(probability=True)
            elif model_choice == 'Naive Bayes':
                model = GaussianNB()
            elif model_choice == 'XGBoost' and xgb_available:
                model = XGBClassifier()

            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            acc = accuracy_score(y_test, y_pred)

            st.success(f"✅ Model trained! Accuracy: {acc:.2f}")
            st.text("Classification Report:")
            st.text(classification_report(y_test, y_pred))

            cm = confusion_matrix(y_test, y_pred, labels=model.classes_)
            fig_cm, ax_cm = plt.subplots()
            disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=model.classes_)
            disp.plot(ax=ax_cm)
            st.subheader("🧮 Confusion Matrix")
            st.pyplot(fig_cm)

            if len(model.classes_) == 2 and hasattr(model, "predict_proba"):
                st.subheader("📈 ROC Curve")
                y_proba = model.predict_proba(X_test)[:, 1]
                fpr, tpr, _ = roc_curve(y_test, y_proba)
                roc_auc = auc(fpr, tpr)

                fig_roc, ax_roc = plt.subplots()
                ax_roc.plot(fpr, tpr, label=f'AUC = {roc_auc:.2f}')
                ax_roc.plot([0, 1], [0, 1], 'k--')
                ax_roc.set_xlabel("False Positive Rate")
                ax_roc.set_ylabel("True Positive Rate")
                ax_roc.set_title("ROC Curve")
                ax_roc.legend()
                st.pyplot(fig_roc)
