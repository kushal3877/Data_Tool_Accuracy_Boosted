# DataTool: Excel/CSV Analyzer with Streamlit

## Description
A simple data science tool that allows users to:
- Upload CSV or Excel files
- Select a target column for prediction
- Automatically trains a Random Forest Classifier
- Displays model accuracy and classification report

## Why RandomForestClassifier?
- Works well with tabular data
- Handles both numerical and categorical features
- Less tuning needed, robust to overfitting

## How to Run
```bash
pip install -r requirements.txt
streamlit run app.py
```